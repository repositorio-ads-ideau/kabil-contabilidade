package br.com.jogo.api.services;

import org.springframework.stereotype.Service;

@Service
public interface ExecutaService {
	public void executa();
}
