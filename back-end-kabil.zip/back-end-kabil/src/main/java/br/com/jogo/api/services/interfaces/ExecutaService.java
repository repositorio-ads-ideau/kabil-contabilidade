package br.com.jogo.api.services.interfaces;

public interface ExecutaService {
	public void executa();
}
